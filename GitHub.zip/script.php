    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.nav.min.js"></script>
    <script src="../../../../cdn.polyfill.io/v2/polyfill.mindee7.js?features=Set,Array.from,Object.assign,Array.prototype.find,Array.prototype.includes"></script>
    <script src="js/shuffle.min.js"></script>
    <script src="js/lity.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>