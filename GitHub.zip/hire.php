<section class="single-section section-fixed-bg section-overlay-bg hire-area" id="hire-area">
        <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <h1 class="hire-title">Let's Work Together!</h1>
                    <p class="hire-description">I am available for freelance projects. Hire me and get your project done.</p>
                    <a class="btn hire" data-scroll href="#contact-area" role="button">Hire Me</a>
                </div>
            </div>
        </div>
</section>