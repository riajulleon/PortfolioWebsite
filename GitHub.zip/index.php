<!doctype html>
<html lang="zxx">

<?php include 'header.php'; ?>

<body>

    <!-- preloader -->
    
        <?php include 'preloader.php'; ?> 
    
    <!-- preloader -->

     
    <!-- About Area -->   
    
        <?php include 'headerarea.php'; ?>   
          
    <!-- About Area -->
    
    <!-- Services Area -->
    
    <?php include 'service.php'; ?> 
    
    <!-- Services Area -->

    
    <!-- Hire Area -->
    
    <?php include 'hire.php'; ?> 
    
    <!-- Hire Area -->
    
    <!-- Portfolio Area -->
    
    <?php include 'protfolio.php'; ?>
    
    <!-- Portfolio Area -->
    
    <!-- Testimonials Area -->
    
    <?php include 'testimonials.php'; ?>
    
    <!-- Testimonials Area -->
    
    <!-- Team Area -->
    
    <?php include 'team.php'; ?>
    
    <!-- Team Area -->
    
    <!-- Contact Area -->
    
    <?php include 'contact.php'; ?>
    
    <!-- Contact Area -->
    
    <!-- Footer Area -->
    
    <?php include 'footer.php'; ?>
    
</div>

    <!-- Footer Area -->
    
    <?php include 'script.php'; ?>
    
    <!-- Footer Area -->

</body>

</html>