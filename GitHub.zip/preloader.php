    <div class="preloader">
        <div class="preloader-section preloader-right">
        </div>
        <div class="preloader-section preloader-left">
        </div>
        <div class="preloader-icon">
            <span class="loading-dot loading-dot-1"></span>
            <span class="loading-dot loading-dot-2"></span>
            <span class="loading-dot loading-dot-3"></span>
        </div>
    </div>